

const createError = require('http-errors');
const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');
const logger = require('morgan');
const hbs = require('hbs');

// Core Database Connection Injection Layer
require('./app_api/models/db');

// Routing middleware definitions
const indexRouter = require('./app_server/routes/index');
const usersRouter = require('./app_server/routes/users');
const travelRouter = require('./app_server/routes/travel'); 
// Refactor: Import the newly established REST API router
const apiRouter = require('./app_api/routes/index');

const app = express();

// View engine architectural configuration
app.set('views', path.join(__dirname, 'app_server', 'views'));
app.set('view engine', 'hbs');

// Register modular Handlebars partials for dynamic layouts
hbs.registerPartials(path.join(__dirname, 'app_server', 'views', 'partials'));

// Core middleware integration
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// Application route mappings
app.use('/', indexRouter);
app.use('/users', usersRouter);
app.use('/travel', travelRouter); 
// Refactor: Mount the REST API routes to the top-level "/api" endpoint path
app.use('/api', apiRouter);

// Catch 404 resource exceptions and route to error management handler
app.use(function(req, res, next) {
  next(createError(404));
});

// Global application error resolution handler
app.use(function(err, req, res, next) {
  // Populate message and contextual error stacks uniquely for dev builds
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // Execute error layout rendering
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
