const mongoose = require('mongoose');
require('./app_api/models/db'); 
const Trip = mongoose.model('trips');

const sampleTrips = [
  {
    code: "GALP210217",
    name: "Galapagos Islands Cruise",
    duration: "7 nights", // Aligned to schema validation requirements
    start: new Date("2027-02-17"),
    resort: "Celebrity Xpedition",
    price: "4299.00",    // Aligned to schema validation requirements
    image: "galapagos.jpg",
    description: "Explore the historic pristine volcanic islands."
  },
  {
    code: "TAJA210217",
    name: "Taj Mahal Highlight Tour",
    duration: "5 nights", // Aligned to schema validation requirements
    start: new Date("2027-03-10"),
    resort: "The Oberoi Amarvilas",
    price: "2150.00",    // Aligned to schema validation requirements
    image: "tajmahal.jpg",
    description: "A magical journey visiting India's most famous monuments."
  }
];

const seedDB = async () => {
    try {
        await Trip.deleteMany({});
        await Trip.insertMany(sampleTrips);
        console.log("Database successfully seeded with trips!");
    } catch (err) {
        console.error("Error seeding database:", err);
    } finally {
        mongoose.connection.close();
        console.log("Mongoose connection cleanly disconnected from target database cluster.");
    }
};

seedDB();
