const express = require('express');
const router = express.Router();
const controller = require('../controllers/travel');

/* Map root path request parameters directly to the travel list handler */
router.get('/', controller.travelList);

module.exports = router;
