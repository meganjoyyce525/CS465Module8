/**
 * Travel Controller
 * Handles the storage and distribution of customer-facing travel package datasets.
 * Bridges application JSON models directly into Handlebars (HBS) view engines.
 */

// Define hardcoded trip data structured to match the client wireframe properties
const trips = [
    {
        code: 'RESV2601',
        name: 'Resort Vacation',
        image: 'resort.jpg',
        duration: '7 Days / 6 Nights',
        price: '$1,499.00',
        description: 'Enjoy a luxury stay at our premier resort location with all-inclusive amenities.'
    },
    {
        code: 'BCHG2602',
        name: 'Beach Getaway',
        image: 'beach.jpg',
        duration: '5 Days / 4 Nights',
        price: '$899.00',
        description: 'Relax on white sandy beaches and take in beautiful ocean views.'
    }
];

/**
 * GET Travel List View Handler
 * Renders the structured travel package directory page using dynamic contextual JSON arrays.
 */
const travelList = (req, res) => {
    res.render('travel', { 
        title: 'Travlr Getaways', 
        trips: trips 
    });
};

// Export controller functionality for integration with application router paths
module.exports = {
    travelList
};
