const mongoose = require('mongoose');
const Trip = mongoose.model('trips'); 

// GET /api/trips - Finds and returns all trips
const tripsList = async (req, res) => {
    try {
        const trips = await Trip.find({}).exec();
        
        if (!trips || trips.length === 0) {
            return res.status(404).json({ "message": "No trips found in database" });
        }
        return res.status(200).json(trips);
    } catch (err) {
        return res.status(500).json(err);
    }
};


const tripsFindByCode = async (req, res) => {
    try {
        const { tripCode } = req.params;
        const trip = await Trip.find({ 'code': tripCode }).exec();
        
        if (!trip || trip.length === 0) {
            return res.status(404).json({ "message": `Trip with code ${tripCode} not found` });
        }
        return res.status(200).json(trip);
    } catch (err) {
        return res.status(500).json(err);
    }
};

module.exports = {
    tripsList,
    tripsFindByCode
};
