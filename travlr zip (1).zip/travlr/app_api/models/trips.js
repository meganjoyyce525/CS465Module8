/**
 * Trips Data Model Schema Definition
 * Implements strict data layer structural validation rules utilizing Mongoose ODM.
 * Formats data properties to align precisely with client wireframe specifications.
 */

const mongoose = require('mongoose');

// Define structural layout validations for travel package records
const tripSchema = new mongoose.Schema({
    code: {
        type: String,
        required: true,
        unique: true,
        index: true,
        trim: true
    },
    name: {
        type: String,
        required: true,
        trim: true
    },
    image: {
        type: String,
        required: true,
        trim: true
    },
    duration: {
        type: String,
        required: true,
        trim: true
    },
    price: {
        type: String,
        required: true,
        trim: true
    },
    description: {
        type: String,
        required: true,
        trim: true
    }
});

// Compile and export data schema directly into operational model component
module.exports = mongoose.model('trips', tripSchema);
