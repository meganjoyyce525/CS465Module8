/**
 * Database Access Module
 * Establishes and manages a lifecycle connection pool to the MongoDB NoSQL instance.
 * Utilizes the Mongoose ODM library to listen for connection status and termination triggers.
 */

const mongoose = require('mongoose');

// Configure local MongoDB connection URI string for Travlr Getaways database instance
const dbURI = 'mongodb://127.0.0.1:27017/travlr';

// Initiate connection pool
mongoose.connect(dbURI);

// Log message when connection is established
mongoose.connection.on('connected', () => {
    console.log(`Mongoose successfully established database connection to: ${dbURI}`);
});

// Log error message if connection fails
mongoose.connection.on('error', (err) => {
    console.log(`Mongoose transaction connection error encountered: ${err}`);
});

// Log message when connection is disconnected
mongoose.connection.on('disconnected', () => {
    console.log('Mongoose connection cleanly disconnected from target database cluster.');
});

/**
 * Graceful Shutdown Handler
 * Safely closes active connection pools before completing structural node runtime termination.
 */
const gracefulShutdown = (msg, callback) => {
    mongoose.connection.close(() => {
        console.log(`Mongoose connection severed via explicit trigger: ${msg}`);
        callback();
    });
};

// Listen for nodemon restart notifications
process.once('SIGUSR2', () => {
    gracefulShutdown('Nodemon restart routine executed', () => {
        process.kill(process.pid, 'SIGUSR2');
    });
});

// Listen for standard application termination triggers
process.on('SIGINT', () => {
    gracefulShutdown('Application process termination executed', () => {
        process.exit(0);
    });
});

// Require underlying data models into single initial runtime register
require('./trips');
